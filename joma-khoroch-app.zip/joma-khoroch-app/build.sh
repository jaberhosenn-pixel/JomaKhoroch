set -e
cd "$(dirname "$0")"
npm install
npx cap add android
cp -r icons/* android/app/src/main/res/
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#096349</color>\n</resources>\n' > android/app/src/main/res/values/ic_launcher_background.xml
sed -i 's#<application#<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application#' android/app/src/main/AndroidManifest.xml
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
mkdir -p ../out
cp app/build/outputs/apk/debug/app-debug.apk ../out/JomaKhoroch.apk
