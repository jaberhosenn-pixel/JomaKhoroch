# জমা-খরচ (Joma-Khoroch)
জিপ আপলোড করলে Actions নিজে APK বানাবে। Artifacts থেকে `JomaKhoroch-APK` নামান।
